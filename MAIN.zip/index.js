//Replace the arguments below
//space,scary,military,romantic,cowboy,fantasy,superhero
favouriteMovieGenre("space")
//watermelon,tomato,banana,orange,avocado,blueberry
favouriteFruit("orange")
//light,dark
favouriteMode("dark")
//sharp,soft,round
favouriteEdgeStyle("sharp")